package java_frappe.problems.week8;

public class Book {
    private String title;
    public Book(String title) {
        this.title = title;
    }
    // 책 정보를 문자열로 반환
    public String getTitle() {
        return title;
    }
}
