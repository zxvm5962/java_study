package java_frappe.problems.week7;

public class MyException_B extends MyException_A{
    public String toString() {
        return "I am a Myexception_B object";
    }
}
