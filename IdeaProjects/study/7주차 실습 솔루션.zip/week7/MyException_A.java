package java_frappe.problems.week7;

public class MyException_A extends Exception{
    public String toString() {
        return "I am a Myexception_A object";
    }
}

