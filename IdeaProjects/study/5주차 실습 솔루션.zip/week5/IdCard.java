package java_frappe.problems.week5;

public class IdCard {
    String name;
    int age;

    public IdCard(String name, int age) {
        this.name = name;
        this.age = age;
    }

}
