package java_frappe.problems.week4;

public class Professor {
    int height;
    int weight;
    int age;

    void eat() {
        this.weight += 4;
    }

    void teach() {
        this.age += 3;
    }

    void score() {
        this.weight -= 5;
    }
}