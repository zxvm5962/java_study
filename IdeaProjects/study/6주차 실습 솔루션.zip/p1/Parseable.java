package java_frappe.problems.week6.p1;

public interface Parseable {
    void parse(String fileName);
    boolean typeCheck(String fileName);

}
